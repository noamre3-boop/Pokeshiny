package com.noam.shinyguard;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
public class MainActivity extends Activity {
 private android.content.SharedPreferences prefs;
 private LinearLayout layout;private Preview preview;private TextView status,modeLabel;
 private EditText threshold;private Switch tap;private Spinner apps;
 private Bitmap sample;private final ArrayList<String> packages=new ArrayList<>();
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable update=new Runnable(){public void run(){status.setText(GuardService.status+"\n"+(GuardService.armed?"ARMED":"DISARMED"));handler.postDelayed(this,700);}};
 @Override public void onCreate(Bundle saved){super.onCreate(saved);prefs=getSharedPreferences("guard",0);
  ScrollView scroll=new ScrollView(this);layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(28,28,28,50);scroll.addView(layout);setContentView(scroll);
  text("SHINY GUARD",25);text("עוזר עצירה ניסיוני • Android 11 ומעלה",16);
  text("לא מזהה שייני באופן כללי. טען צילום מסך של השייני המסוים, סמן אזור קטן סביב היצור וכייל את נקודת העצירה. תנועת ספרייט, שינוי צבעים או מהירות אמולטור עלולים לגרום להחמצה. אין הבטחה שלא תברח משייני.",15);
  text("פרטיות: בזמן הפעלה מפורשת בלבד, שירות הנגישות קורא צילומי מסך מקומית. אין הרשאת אינטרנט. במצב לחיצה הוא שולח נגיעה אחת בנקודה שבחרת ואז מפסיק. אפשר לכבות בכל רגע בהגדרות נגישות.",14);
  button("1. הפעל שירות בהגדרות נגישות",()->new AlertDialog.Builder(this).setTitle("אישור צפייה ולחיצה").setMessage("השירות יוכל לצלם את המסך ולשלוח נגיעה. אין כאן הרשאה לצילום בלבד. הפעל רק אם אתה מסכים; הניטור לא מתחיל עד שתלחץ הפעלה.").setPositiveButton("פתח הגדרות",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).setNegativeButton("ביטול",null).show());
  text("2. בחר את האמולטור",16);apps=new Spinner(this);layout.addView(apps);loadApps();
  button("3. טען צילום מסך מלא של שייני",()->{stop();Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,12);});
  modeLabel=text("סמן מלבן סביב ספרייט היריב, בלי טקסט או כפתורים",14);
  preview=new Preview();layout.addView(preview,new LinearLayout.LayoutParams(-1,620));
  button("סימון אזור זיהוי: גרור מלבן",()->{preview.mode=0;modeLabel.setText("גרור מלבן סביב ספרייט השייני בצילום");});
  button("סימון כפתור עצירה: נגיעה אחת",()->{preview.mode=1;modeLabel.setText("גע במרכז הריבוע האדום של הקליקר בצילום");});
  text("סף הבדל צבע: נמוך = מחמיר. ברירת מחדל 0.04; מותר 0.005–0.12",14);
  threshold=new EditText(this);threshold.setInputType(8194);threshold.setText(String.valueOf(prefs.getFloat("threshold",.04f)));layout.addView(threshold);
  tap=new Switch(this);tap.setText("שלח לחיצה אוטומטית לאחר התאמה (כבוי = התרעה בלבד)");tap.setChecked(prefs.getBoolean("tap",false));layout.addView(tap);
  button("4. שמור כיול",()->saveCalibration());
  button("5. הפעל ניטור — עבור לאמולטור",()->{if(!saveCalibration())return;if(GuardService.instance==null){toast("הפעל שירות נגישות קודם");return;}GuardService.instance.arm();status.setText(GuardService.status);});
  button("עצור ניטור מיד",this::stop);
  status=text("DISARMED",16);
  text("בדיקה ראשונה: השאר לחיצה אוטומטית כבויה ובדוק שהשייני מפעיל התרעה ושצילום רגיל אינו מפעיל התרעה. רק אחר כך הפעל לחיצה. אל תזיז את הקליקר או תשנה כיוון מסך לאחר כיול. אישור נגיעה אינו אישור שהקליקר אכן עצר. אפליקציות נגישות שונות עלולות להפריע זו לזו.",14);
  try{sample=BitmapFactory.decodeFile(new File(getFilesDir(),"sample.png").getPath());}catch(Exception ignored){}
 }
 private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(0,10,0,10);layout.addView(t);return t;}
 private void button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());layout.addView(b);}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 private void stop(){if(GuardService.instance!=null)GuardService.instance.stop("Stopped by user");}
 private void loadApps(){
  ArrayList<String> labels=new ArrayList<>();labels.add("בחר אמולטור");packages.add("");
  Intent query=new Intent(Intent.ACTION_MAIN);query.addCategory(Intent.CATEGORY_LAUNCHER);
  List<ResolveInfo> results=getPackageManager().queryIntentActivities(query,0);
  results.sort((a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
  HashSet<String> seen=new HashSet<>();int selected=0;
  for(ResolveInfo r:results){String p=r.activityInfo.packageName;if(p.equals(getPackageName())||!seen.add(p))continue;packages.add(p);labels.add(r.loadLabel(getPackageManager())+" • "+p);if(p.equals(prefs.getString("target","")))selected=packages.size()-1;}
  apps.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));apps.setSelection(selected);
 }
 private boolean saveCalibration(){
  if(GuardService.armed){toast("עצור ניטור לפני שינוי כיול");return false;}
  if(sample==null){toast("טען צילום מסך של שייני");return false;}
  if(apps.getSelectedItemPosition()==0){toast("בחר אמולטור");return false;}
  if(!preview.regionChosen||!preview.pointChosen){toast("סמן אזור זיהוי ונקודת עצירה");return false;}
  float limit;try{limit=Float.parseFloat(threshold.getText().toString());if(!Float.isFinite(limit)||limit<.005f||limit>.12f)throw new Exception();}catch(Exception e){toast("סף לא תקין");return false;}
  RectF r=preview.region;int x=Math.round(r.left*sample.getWidth()),y=Math.round(r.top*sample.getHeight());
  int w=Math.max(1,Math.round(r.width()*sample.getWidth())),h=Math.max(1,Math.round(r.height()*sample.getHeight()));
  w=Math.min(w,sample.getWidth()-x);h=Math.min(h,sample.getHeight()-y);
  if(w<12||h<12){toast("אזור קטן מדי");return false;}
  Bitmap crop=Bitmap.createBitmap(sample,x,y,w,h),small=Bitmap.createScaledBitmap(crop,64,64,true);
  try(FileOutputStream out=openFileOutput("reference.png",0)){small.compress(Bitmap.CompressFormat.PNG,100,out);}catch(Exception e){toast("שמירת תמונה נכשלה");return false;}finally{if(small!=crop)small.recycle();crop.recycle();}
  prefs.edit().putFloat("rx",r.left).putFloat("ry",r.top).putFloat("rw",r.width()).putFloat("rh",r.height()).putFloat("tx",preview.tx).putFloat("ty",preview.ty).putFloat("ratio",sample.getWidth()/(float)sample.getHeight()).putFloat("threshold",limit).putBoolean("tap",tap.isChecked()).putString("target",packages.get(apps.getSelectedItemPosition())).putBoolean("regionChosen",true).putBoolean("pointChosen",true).apply();toast("הכיול נשמר");return true;
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=12||result!=RESULT_OK||data==null)return;
  try{Uri uri=data.getData();BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,options);}if(options.outWidth<1||options.outHeight<1||options.outWidth>6000||options.outHeight>6000)throw new IOException("Image too large");options.inJustDecodeBounds=false;Bitmap next;try(InputStream in=getContentResolver().openInputStream(uri)){next=BitmapFactory.decodeStream(in,null,options);}if(next==null)throw new IOException();if(sample!=null)sample.recycle();sample=next;preview.regionChosen=false;preview.pointChosen=false;try(FileOutputStream out=openFileOutput("sample.png",0)){sample.compress(Bitmap.CompressFormat.PNG,100,out);}preview.invalidate();toast("סמן אזור זיהוי וכפתור עצירה מחדש");}catch(Exception e){toast("לא ניתן לטעון תמונה");}
 }
 @Override protected void onResume(){super.onResume();handler.post(update);}
 @Override protected void onPause(){handler.removeCallbacks(update);super.onPause();}
 private class Preview extends View {
  int mode=0;float tx=prefs.getFloat("tx",.655f),ty=prefs.getFloat("ty",.389f),sx,sy;
  boolean regionChosen=prefs.getBoolean("regionChosen",false),pointChosen=prefs.getBoolean("pointChosen",false);
  RectF region=new RectF(prefs.getFloat("rx",.5f),prefs.getFloat("ry",.1f),0,0),display=new RectF();Paint paint=new Paint(3);
  Preview(){super(MainActivity.this);region.right=region.left+prefs.getFloat("rw",.4f);region.bottom=region.top+prefs.getFloat("rh",.2f);}
  @Override protected void onDraw(Canvas c){c.drawColor(Color.rgb(25,30,40));if(sample==null)return;float scale=Math.min(getWidth()/(float)sample.getWidth(),getHeight()/(float)sample.getHeight());float w=sample.getWidth()*scale,h=sample.getHeight()*scale;display.set((getWidth()-w)/2,(getHeight()-h)/2,(getWidth()+w)/2,(getHeight()+h)/2);c.drawBitmap(sample,null,display,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);paint.setColor(Color.CYAN);c.drawRect(display.left+region.left*w,display.top+region.top*h,display.left+region.right*w,display.top+region.bottom*h,paint);paint.setColor(Color.RED);c.drawCircle(display.left+tx*w,display.top+ty*h,12,paint);paint.setStyle(Paint.Style.FILL);}
  @Override public boolean onTouchEvent(android.view.MotionEvent e){if(sample==null||display.width()==0)return false;float x=Math.max(0,Math.min(.999f,(e.getX()-display.left)/display.width())),y=Math.max(0,Math.min(.999f,(e.getY()-display.top)/display.height()));
   if(e.getAction()==MotionEvent.ACTION_DOWN){if(!display.contains(e.getX(),e.getY()))return false;getParent().requestDisallowInterceptTouchEvent(true);sx=x;sy=y;}
   if(mode==1){tx=x;ty=y;if(e.getAction()==MotionEvent.ACTION_UP)pointChosen=true;}else{region.set(Math.min(sx,x),Math.min(sy,y),Math.max(sx,x),Math.max(sy,y));if(e.getAction()==MotionEvent.ACTION_UP)regionChosen=region.width()>.01f&&region.height()>.01f;}
   if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL)getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
  }
 }
}
