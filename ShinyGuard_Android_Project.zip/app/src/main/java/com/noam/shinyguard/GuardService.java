package com.noam.shinyguard;
import android.accessibilityservice.*;
import android.view.accessibility.*;
import android.content.*;
import android.graphics.*;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.media.*;
import android.view.Display;
import java.io.File;
import java.util.Locale;
public class GuardService extends AccessibilityService {
 public static GuardService instance;
 public static volatile boolean armed=false;
 public static volatile String status="Not armed";
 private final Handler handler=new Handler(Looper.getMainLooper());
 private int[] reference; private int hits=0,failures=0; private boolean busy=false;
 private final Runnable loop=()->capture();
 private android.content.SharedPreferences prefs(){return getSharedPreferences("guard",0);}
 @Override public void onServiceConnected(){instance=this;status="Accessibility connected";}
 @Override public void onAccessibilityEvent(AccessibilityEvent event){}
 @Override public void onInterrupt(){stop("Interrupted");}
 @Override public void onDestroy(){stop("Service disconnected");instance=null;super.onDestroy();}
 public boolean arm(){
  if(armed)return false;
  Bitmap b=BitmapFactory.decodeFile(new File(getFilesDir(),"reference.png").getPath());
  if(b==null){status="Load a shiny reference first";return false;}
  reference=new int[64*64];b.getPixels(reference,0,64,0,0,64,64);b.recycle();
  if(prefs().getString("target","").isEmpty()){status="Choose emulator first";return false;}
  hits=0;failures=0;armed=true;status="Armed: waiting for selected emulator";handler.postDelayed(loop,4000);return true;
 }
 public void stop(String message){armed=false;hits=0;handler.removeCallbacks(loop);status=message;}
 private boolean targetVisible(){
  String target=prefs().getString("target","");
  try {for(AccessibilityWindowInfo w:getWindows()){
   AccessibilityNodeInfo n=w.getRoot();
   if(n!=null&&target.contentEquals(n.getPackageName()==null?"":n.getPackageName()))return true;
  }}catch(Exception ignored){}
  return false;
 }
 private void schedule(){if(armed)handler.postDelayed(loop,600);}
 private void capture(){
  if(!armed)return;
  if(busy){schedule();return;}
  PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
  if(!pm.isInteractive()){stop("Screen off: disarmed");return;}
  if(!targetVisible()){hits=0;status="Waiting for selected emulator";schedule();return;}
  busy=true;
  try {takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
   @Override public void onSuccess(ScreenshotResult result){
    Bitmap bitmap=null,hardware=null;
    HardwareBuffer buffer=result.getHardwareBuffer();
    try{
     hardware=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());
     if(hardware==null)throw new IllegalStateException("No screenshot");
     bitmap=hardware.copy(Bitmap.Config.ARGB_8888,false);
     if(armed)inspect(bitmap);
     failures=0;
    }catch(Exception e){stop("Capture/match error: "+e.getClass().getSimpleName());}
    finally{if(bitmap!=null)bitmap.recycle();if(hardware!=null)hardware.recycle();buffer.close();busy=false;schedule();}
   }
   @Override public void onFailure(int code){busy=false;hits=0;failures++;status="Screenshot error "+code;if(failures>=3)stop("Capture failed 3 times: disarmed");schedule();}
  });}catch(Exception e){busy=false;stop("Screenshot unavailable");}
 }
 private void inspect(Bitmap b){
  float ratio=b.getWidth()/(float)b.getHeight(),expected=prefs().getFloat("ratio",ratio);
  if(Math.abs(ratio-expected)/expected>.03f){stop("Screen shape changed: recalibrate");return;}
  int x=Math.round(prefs().getFloat("rx",.5f)*b.getWidth()),y=Math.round(prefs().getFloat("ry",.1f)*b.getHeight());
  int w=Math.max(1,Math.round(prefs().getFloat("rw",.4f)*b.getWidth())),h=Math.max(1,Math.round(prefs().getFloat("rh",.2f)*b.getHeight()));
  if(x<0||y<0||x+w>b.getWidth()||y+h>b.getHeight()){stop("Invalid crop: recalibrate");return;}
  Bitmap crop=Bitmap.createBitmap(b,x,y,w,h),small=Bitmap.createScaledBitmap(crop,64,64,true);
  int[] pixels=new int[4096];small.getPixels(pixels,0,64,0,0,64,64);
  double error=Matcher.distance(reference,pixels),fraction=Matcher.closeFraction(reference,pixels,40);
  float threshold=prefs().getFloat("threshold",.04f);
  boolean match=error<=threshold&&fraction>=.85;
  hits=match?hits+1:0;
  status=String.format(Locale.US,"Difference %.4f / %.3f • close %.0f%% • hits %d/2",error,threshold,fraction*100,hits);
  if(small!=crop)small.recycle();crop.recycle();
  if(hits>=2){
   boolean tap=prefs().getBoolean("tap",false);
   stop(tap?"Match: sending one stop tap":"Match: ALERT ONLY; clicker not stopped");
   alert();
   if(tap){
    float tx=prefs().getFloat("tx",.655f)*b.getWidth(),ty=prefs().getFloat("ty",.389f)*b.getHeight();
    Path path=new Path();path.moveTo(tx,ty);
    GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,90)).build();
    boolean sent=dispatchGesture(gesture,new GestureResultCallback(){
     @Override public void onCompleted(GestureDescription g){status="Stop tap delivered; VERIFY clicker stopped. Disarmed.";}
     @Override public void onCancelled(GestureDescription g){status="Stop tap cancelled! Stop clicker manually. Disarmed.";alert();}
    },handler);
    if(!sent)status="Tap rejected! Stop clicker manually. Disarmed.";
   }
  }
 }
 private void alert(){
  try{Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);v.vibrate(VibrationEffect.createWaveform(new long[]{0,300,100,300,100,500},-1));}catch(Exception ignored){}
  try{ToneGenerator tone=new ToneGenerator(AudioManager.STREAM_ALARM,90);tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,1200);handler.postDelayed(tone::release,1500);}catch(Exception ignored){}
 }
}
