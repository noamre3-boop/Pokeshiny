package com.noam.shinyguard;
public final class Matcher {
 public static double distance(int[] a,int[] b) {
  if(a==null||b==null||a.length!=b.length||a.length==0)throw new IllegalArgumentException();
  long sum=0;
  for(int i=0;i<a.length;i++)for(int s=0;s<=16;s+=8)sum+=Math.abs(((a[i]>>s)&255)-((b[i]>>s)&255));
  return sum/(a.length*3.0*255.0);
 }
 public static double closeFraction(int[] a,int[] b,int tolerance){
  int count=0;
  for(int i=0;i<a.length;i++){
   boolean close=true;
   for(int s=0;s<=16;s+=8)if(Math.abs(((a[i]>>s)&255)-((b[i]>>s)&255))>tolerance)close=false;
   if(close)count++;
  }
  return count/(double)a.length;
 }
}
